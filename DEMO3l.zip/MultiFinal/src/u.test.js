const {generateTest} = require('./game')

test("color of the snake",() => {

}